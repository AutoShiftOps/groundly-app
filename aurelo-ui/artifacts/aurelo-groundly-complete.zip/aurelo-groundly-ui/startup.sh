#!/bin/bash
set -euo pipefail
cd /workspace

if curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
  exit 0
fi

npm run dev >/tmp/aurelo-dev.log 2>&1 &
disown || true
exit 0
