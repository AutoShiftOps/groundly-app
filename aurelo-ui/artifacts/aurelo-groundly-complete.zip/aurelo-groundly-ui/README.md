# Aurelo / Groundly UI

Complete React app: idea home → train theater → Groundly ReportView.

Matches `assets/images/report-ux-mock.png` for the report (thin app nav, top framework pills, TAM concentric rings + table). Other frameworks use the same card pattern (structured visual + citations + Ask AI) by hydrating text into PESTEL/SWOT/Porter/STP/BMC/BCG/Ansoff/Value Chain/Scorecard layouts when the API does not return those fields.

Train compartments can be revisited later (`src/components/analyze/TrainScene.tsx`).

## Run

```bash
npm install
npm run dev
```

Opens on port 8080. Set `GROUNDLY_API_URL` (or `VITE_API_BASE_URL`) to your Groundly API (`https://groundly-api.onrender.com`) for live `/api/analyze` and `/api/ask`. If Render is cold, the app falls back to a same-shape local/Grok report so every tab still works.

## Navigation

Analyze, Projects, Insights, Market, Reports, and Settings all route. Reports opens the full Groundly ReportView. Analyze starts a new idea.

## Merge into Groundly

This snapshot also lives on branch `feature/aurelo-ui` as `aurelo-ui/` plus `frontend/src/components/HomeScreen.tsx`.

PR: https://github.com/AutoShiftOps/groundly-app/pull/22

To merge without replacing `frontend/`: keep `frontend/` as the production Vite app and use `aurelo-ui/` for evaluation. To make Groundly *be* this UI, copy:

- `src/components/report/ReportView.jsx`
- `src/lib/groundly/*`
- idea form + store wiring

into `frontend/`, keeping `App.tsx` routing Home → Loading → Report.

## Key files

| Path | Role |
|---|---|
| `src/routes/index.tsx` | Compose → analyze → theater → report |
| `src/components/report/ReportView.jsx` | Mock-matched report (all 10 frameworks, Ask AI, share, print) |
| `src/lib/groundly/analyze.ts` | `POST /api/analyze` and `POST /api/ask` |
| `src/lib/groundly/hydrate.ts` | Fill structured visuals from prose when the API only returns text |
| `src/components/analyze/TrainScene.tsx` | Labeled train compartments |
